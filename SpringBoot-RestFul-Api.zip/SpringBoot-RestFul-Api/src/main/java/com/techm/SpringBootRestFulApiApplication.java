package com.techm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestFulApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestFulApiApplication.class, args);
	}

}
